﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Simulatore_TCP
{
    public partial class Inserimento_dati : Form
    {

        public int flag_radio; //una variabile che mi servirà per discernere se è stata scelta in input la modalità di gestione della congestione Reno o Tahoe

        public float flag_input1 = 100; //mi serviranno questi flag per fare successivamente dei controlli sui dati inseriti in input (validazione dell'input fatta sia con il codice che dalla form stessa); 101, per esempio, perché non potrebbe essere preso in input
        public float flag_input2 = 1000;
        public int flag_input3 = 0;
        public float flag_input4 = 0;
        public int flag_input5 = 0;



        public Inserimento_dati() 
        {
            InitializeComponent();
        }

        public float getText1() //tramite queste due funzioni prendo ciò che viene messo in input nelle due caselle di testo e lo converto in float
        {
            return float.Parse(maskedTextBox1.Text);
        }
        public int getText2()
        {
            return int.Parse(maskedTextBox2.Text);
        }
        public int getText3()
        {
            return int.Parse(maskedTextBox3.Text);
        }
        public int getText4()
        {
            return int.Parse(maskedTextBox4.Text);
        }



        private void label1_Click(object sender, EventArgs e) //metodo necessario per l'esistenza di questo controllo (non si può cancellare)
        {

        }

        
        private void toolTip1_Popup(object sender, PopupEventArgs e) //è presente un tooltip
        {

        }
        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e) //qui gestisco il rifiuto dell'input che ha messo l'utente facendo comparire delle indicazioni nel tooltip a schermo
        {
            toolTip1.ToolTipTitle = "Input non valido";
            toolTip1.Show("Bisogna digiare un numero tra 0 e 99", maskedTextBox1, maskedTextBox1.Location, 5000);

        }
        private void maskedTextBox2_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            toolTip1.ToolTipTitle = "Input non valido";
            toolTip1.Show("Bisogna digiare un numero tra 0 e 999", maskedTextBox1, maskedTextBox1.Location, 5000);
        }
        private void maskedTextBox3_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            toolTip1.ToolTipTitle = "Input non valido";
            toolTip1.Show("Bisogna digiare un numero diverso da 0", maskedTextBox1, maskedTextBox1.Location, 5000);
        }
        


        private void radioButton1_CheckedChanged(object sender, EventArgs e) //se scelgo Reno setto l'attributo flag a 0, altrimenti a 1; l'unica miglioria, se necessaria, sarebbe costringere l'utente a riempire tutti queste caselle e fare un controllo su questi dati immessi, altrimenti non si può andare avanti nella simulazione
        {
            this.flag_radio = 0;
            this.flag_input5 = 1; //cambiamo il flag perché la modalità è stata scelta/settata
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            this.flag_radio = 1;
            this.flag_input5 = 1;
        }



        private void button1_Click(object sender, EventArgs e) //quando viene premuto il bottone cerco di aprire le form Simulazione e Risultati, istanziare gli host A e B e chiudere Inserimento_dati questa stessa form
        {
            this.flag_input1 = float.Parse(maskedTextBox1.Text);
            this.flag_input2 = float.Parse(maskedTextBox2.Text);
            this.flag_input3 = int.Parse(maskedTextBox3.Text);
            this.flag_input4 = int.Parse(maskedTextBox4.Text);
            if (this.flag_input1 != 100 && this.flag_input2 != 1001 && this.flag_input3 != 0 && this.flag_input4 != 0 && this.flag_input5 != 0) //qui verifico che tutti i campi, essendo fondamentali/primari, siano stati riempiti dall'utente
            {
                this.Hide(); //e non close, perché A e B devono prelevare i dati, e quindi non posso deallocare risorse

                Simulazione form2 = new Simulazione();

                form2.Show();
                //Application.Run(form2);

                Macchina_a_stati_TCP m = new Macchina_a_stati_TCP(this, form2, form2.form3);
                new Thread(new ThreadStart(m.Run1)).Start(); //facciamo partire il mittente
                System.Console.WriteLine("THREAD 1 ISTANZIATO");
                //System.Threading.Thread.Sleep(1000); //aspetto un secondo per sincronizzare, tanto all'inizio deve partire il mittente
                new Thread(new ThreadStart(m.Run2)).Start(); //facciamo partire il ricevente
                System.Console.WriteLine("THREAD 2 ISTANZIATO");

            }
            else
            {
                if (this.flag_input2 == 0) { this.maskedTextBox2.ResetText(); toolTip1.ToolTipTitle = "La quantità di dati da trasmettere non può essere nulla"; }
                if (this.flag_input3 == 0) { this.maskedTextBox3.ResetText(); toolTip1.ToolTipTitle = "Il tempo di attesa medio non può essere nullo"; }
                if (this.flag_input4 == 0) { this.maskedTextBox4.ResetText(); toolTip1.ToolTipTitle = "La dimensione del buffer non può essere nulla"; }
                if (this.flag_input5 == 0) { toolTip1.ToolTipTitle = "E' necessario selezionare una modalità di gestione della congestione"; }
            }
        }

    }
}
