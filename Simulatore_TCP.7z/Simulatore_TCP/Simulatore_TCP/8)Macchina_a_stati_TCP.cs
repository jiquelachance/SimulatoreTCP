﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading; //questa l'ho aggiunta io per farlo ereditare dalla classe Thread
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Simulatore_TCP
{
    /*public*/
    class Macchina_a_stati_TCP : Macchina_a_stati_mittente_TCP, Macchina_a_stati_ricevente_TCP, Gestione_congestione //vale sia per il mittente che per il destinatario; implemento 3 interfacce; di default non è public, quindi potrei doverlo metterlo
    {
        //Dati in Input
        public float error_rate; //percentuale di errore di fallimento di invio del segmento, settabile in input dall'interfaccia
        public int dim_message; //simbolicamente MB
        public float tempo_di_attesa_medio; //tempo di attesa medio di ogni operazione, quando chiamo il thread.sleep per scandire il tempo
        public int buffer_di_ricezione;
        public int modalità_congestione; //0 Reno, 1 Tahoe (dall'interfaccia grafica)

        //Form su cui scrivere
        public Inserimento_dati form1;
        public Simulazione form2;
        public Risultati form3;

        //Attributi
        public string state_mitt; //lo stato del mittente
        public string state_ric; //lo stato del ricevente

        public Boolean connesso; //se è true è stata stata stabilita una connessione TCP altrimenti no
        public int num_seq_mitt; //numero di sequenza del mittente, solo simbolico, usato solo nella connessione per renderla più realistica
        public int num_seq_ric; // e del ricevente

        public int dim_rimanenti; //ancora da mandare
        public int[] pacchetti; //array/insieme/finestra di pacchetti (nella teoria, quelli da 0 a base/num_seq_oldest -1 sono quelli che sono stati già inviati e confermati dall'ACK, mentre da base/num_seq_oldest a nextseqnum/num_seq_new-1 sono quelli inviati non ancora confermati, mentre infine i numeri di sequenza da nextseqnum/num_seq_new a base/num_seq_oldest + N (ampiezza finestra)-1 sono quelli che si possono inviare)
        public int num_seq; //dimensione dell'array dei pacchetti che sarà "dinamico", ossia rappresenta i vari numeri di sequenza
        public List<Boolean> list_ack; //"array" degli ACK che manda il ricevente, è il corrispondente dell'array pacchetti del mittente
        public int ack_flag;
        public List<int> list_nak; //pacchetti da reinviare perchè si sono persi
        public int nak_flag;
        public int ack_dup_flag;
        //public int num_seq_next; //sarebbe il nextseqnum, ossia il prossimo numero di sequenza del pacchetto (da inviare)
        public int num_seq_oldest; //sarebbe il sendbase, ossia il numero di sequenza dell'ultimo pacchetto non ancora confermato da un ACK

        public int finestra_di_ricezione; //sarebbe N (o rcvw)
        public int finestra_di_congestione; //per il controllo della congestione (cwnd)

        public float tempo_di_attesa_effettivo_mitt; //quello simulato che si registra in quel momento (RTT dal ricevente al mittente)
        public float tempo_di_attesa_effettivo_ric; //RTT dal mittente al ricevente

        public Thread timer;
        public float timeout;
        //public Boolean boolean_timeout;
        public float sample_rtt; //rtt campione in quel momento
        public float estimated_rtt_old; //valore medio dei vari campioni sample_rtt
        public float estimated_rtt_new;
        public float dev_rtt_old; //variazione RTT
        public float dev_rtt_new;
        public int rtt_flag;
        public float somma_parziale;
        public List<float> list_sample_rtt; //è un array dinamico dove inserisco man mano i vari sample_rtt calcolati che devo memorizzare per cacolare la media dei sample_rtt

        public float error_flag; //campo flag temporaneo che mi servirà in seguito
        //public int flag_ritr; //(ritrasmissione)
        public int flag_num_seq_oldest;

        public Boolean lock_mitt; //servono per sincronizzare
        public Boolean lock_ric;

        public float R; //RTT quando si è verificato la perdita
        public float W; //finestra di congestione quando si è verificata la perdita
        public float throughput_medio;

        public int fine_simulazione;
        //public System.Windows.Forms.PaintEventArgs e;


        public Macchina_a_stati_TCP(Inserimento_dati form1, Simulazione form2, Risultati form3)
        {
            this.form1 = form1;
            this.form2 = form2;
            this.form3 = form3;
            //this.e = form2.e;

            //Inizializzazioni iniziali 

            //il disegno della macchina stati si fa con una funzione che non ha bisogno di essere richiamata (ci pensa la form)
            this.fine_simulazione = 0;
            this.rtt_flag = 0;
            this.ack_flag = 0;
            this.ack_dup_flag = 0;
            //this.flag_ritr = 0;
            this.num_seq = 1;
            //this.num_seq_next = 0;
            this.num_seq_oldest = 0;
            this.flag_num_seq_oldest = 0;
            this.dev_rtt_old = 0; //all'inizio è 0
            this.throughput_medio = 0;

            this.finestra_di_congestione = 1; //inizio dello slow start (controllo congestione)

            this.connesso = false; //all'inizio non è stata fatta la connessione
            this.lock_mitt = false; //all'inizio il mittente deve mandare, quindi solo lui deve essere "attivo"
            this.lock_ric = true; //all'inizio il mittente non ha nulla da ricevere quindi deve aspettare (tra l'altro deve aspettare che si instaura la connessione)
            //this.boolean_timeout = true; //è un flag_timeout che verrà usato nel metodo start_timer

            this.state_mitt = "state1"; //inizializzo a stato 1 (iniziale)

            this.list_nak = new List<int>(); //numeri delle sequenze dei pacchetti da rimandare
            this.list_sample_rtt = new List<float>(); 
            this.list_ack = new List<Boolean>();

            this.state_ric = "state1";

            //this.tempo_di_attesa_effettivo_ric = this.tempo_di_attesa_medio; //la prima volta è questo, poi verrà cambiato 

            System.Console.WriteLine("MACCHINA_A_STATI_TCP INIZIALIZZATA CON SUCCESSO");
        
        }




        //metodo run di Thread
        public void Run1() //per non avere errori quando creo il Thread non posso passargli parametri qui
        {
            System.Console.WriteLine("THREAD 1 INIZIATO");
            //Prelievo dati in input
            this.error_rate = this.form1.getText1(); //funziona
            this.dim_message = this.form1.getText2();
            this.tempo_di_attesa_medio = this.form1.getText3();
            this.buffer_di_ricezione = this.form1.getText4();
            this.modalità_congestione = this.form1.flag_radio;

            this.dim_rimanenti = this.dim_message;

            //tentativo di stabilimento di connessione TCP
            System.Console.WriteLine("THREAD 1 TENTA DI STABILIRE LA CONNESSIONE");
            while (this.connesso == false)
            {
                form2.Aggiungi_testo("Mittente: ha inviato il segmento di SYN=1\n", 1); //stampo a schermo nell'interfaccia Simulazione
                System.Threading.Thread.Sleep((int)(this.tempo_di_attesa_medio)); //per scandire il tempo; ne prendo la parte intera

                this.num_seq_mitt = new Random().Next(1, 100); //mi serve un numero random tra 1 e 100 per implementare la possibilità di fallimento
                if (this.num_seq_mitt <= this.error_rate) form2.Aggiungi_testo("Mittente: Connessione fallita...sto riprovando\n", 1);
                else
                {
                    this.num_seq_ric = new Random().Next(1, 100);
                    form2.Aggiungi_testo("Ricevente: ha inviato il segmento di SYN=1\n", 2);
                    form2.Aggiungi_testo("Ricevente: ha inviato l'ACK " + (this.num_seq_mitt + 1) + "\n", 2);
                    form2.Aggiungi_testo("Ricevente: ha inviato il suo numero di sequenza " + (this.num_seq_ric) + "\n", 2);
                    System.Threading.Thread.Sleep(2500);

                    form2.Aggiungi_testo("Mittente: ha inviato l'ACK" + (this.num_seq_ric) + "\n", 1);
                    form2.Aggiungi_testo("Mittente: Connessione stabilita\n\n\n", 1);
                    form2.Aggiungi_testo("Ricevente: Connessione stabilita\n\n\n", 2);
                    this.connesso = true; //terminiamo il ciclo while
                }
            }
            System.Console.WriteLine("THREAD 1 HA STABILITO LA CONNESSIONE");

            //potrei mettere return; ma conviene creare questa classe come Thread facendola ereditare dall'omonima classe
            
                //while (this.dim_rimanenti != 0) //finché ci sono dati da trasmettere
                while(true)
                {
                    System.Threading.Thread.Sleep(100);
                    System.Console.WriteLine("THREAD 1 ENTRA NEL CICLO WHILE TRUE");

                    lock (this) //sto lockando questa risorsa (Macchina a stati) in  modo che può essere acceduta da un solo thread alla volta, l'importante è saper gestire quale
                    {
                        System.Console.WriteLine("THREAD 1 ENTRA NEL LOCK");

                            if (this.lock_mitt == false) //se il mittente non è bloccato
                            {
                                System.Console.WriteLine("THREAD 1 ENTRA NEL IF THIS.LOCK_MITT == FALSE");
                                switch (this.state_mitt)
                                {
                                    case "state1": //STATO 1:(Attesa) Ricezione chiamata livello superiore e invio pacchetto
                                        System.Console.WriteLine("THREAD 1 ENTRA NELLO STATO 1");
                                        form2.Aggiungi_testo("Mittente: ENTRA NELLO STATO 1, mentre il ricevente è allo stato " + this.state_ric + "\n", 1);
                                        this.state1_mitt();
                                        break;
                                    case "state2": //STATO 2: Attesa ricezione ACK 
                                        System.Console.WriteLine("THREAD 1 ENTRA NELLO STATO 2");
                                        form2.Aggiungi_testo("Mittente: ENTRA NELLO STATO 2, mentre il ricevente è allo stato " + this.state_ric + "\n", 1);
                                        this.state2_mitt();
                                        break;
                                    case "state3": //STATO 3: Ritrasmissione
                                        System.Console.WriteLine("THREAD 1 ENTRA NELLO STATO 3");
                                        form2.Aggiungi_testo("Mittente: ENTRA NELLO STATO 3, mentre il ricevente è allo stato " + this.state_ric + "\n", 1);
                                        this.state3_mitt();
                                        break;
                                    case "state4": //STATO 4: Verifica ricezione
                                        System.Console.WriteLine("THREAD 1 ENTRA NELLO STATO 4");
                                        form2.Aggiungi_testo("Mittente: ENTRA NELLO STATO 4, mentre il ricevente è allo stato " + this.state_ric + "\n", 1);
                                        this.state4_mitt();
                                        break;

                                }
                            }
                        }
                    if (this.dim_rimanenti == 0)
                    {
                        this.lock_ric = true; //il ricevente ha finito

                        System.Console.WriteLine("THREAD 1 FINISCE LA MACCHINA A STATI");
                        form2.Aggiungi_testo("Mittente: sono stati inviati correttamente tutti i pacchetti\n", 1);

                        if (this.R == 0 || this.W == 0)
                        {
                            System.Console.WriteLine("THREAD 1 ENTRA NEL IF THIS.R == 0  O  IF.W == 0");
                            form2.Aggiungi_testo("Errore di esecuzione: R e W non sono stati cambiati, oppure non c'è stata perdita (impossibile)", 1);

                            this.fine_simulazione = 1;

                            this.form2.Final();

                            return;
                        }
                        else
                        {
                            System.Console.WriteLine("THREAD 1 HA THIS.R E THIS.W != 0");
                            this.throughput_medio = (float)(0.75 * this.W) / this.R;
                            form3.Aggiungi_testo("Il throughput medio registrato in questa sessione è pari a: " + this.throughput_medio + "\n");
                            System.Console.WriteLine("THREAD 1 HA FATTO VISUALIZZARE IL THOROUGHPUT");

                            this.fine_simulazione = 1;

                            this.form2.Final();

                            return;
                        }

                        
                    }
            }

        }



        public void Run2()
        {
            System.Console.WriteLine("THREAD 2 INIZIATO");

                //while (this.dim_rimanenti != 0)
                while(true)
                {

                    System.Threading.Thread.Sleep(100); //per aspettare un attimo
                    System.Console.WriteLine("THREAD 2 ENTRA NEL WHILE TRUE");
                    
                    lock (this)
                    {
                        System.Console.WriteLine("THREAD 2 ENTRA NEL LOCK");
                       
                        if (this.fine_simulazione == 1)
                            return;

                        if (this.lock_ric == false) //finchè il ricevente non è bloccato
                    {
                       
                        System.Console.WriteLine("THREAD 2 ENTRA NEL IF THIS.LOCK_RIC == FALSE");
                        switch (this.state_ric)
                        {
                            case "state1": //Manda l'ACK dell'ultimo segmento ricevuto     
                                System.Console.WriteLine("THREAD 2 ENTRA NELLO STATO 1");
                                form2.Aggiungi_testo("Ricevente: ENTRA NELLO STATO 1, mentre il mittente è allo stato " + this.state_mitt+ "\n", 2);
                                this.state1_ric();
                                break;
                            case "state2": //Attesa pacchetti
                                System.Console.WriteLine("THREAD 2 ENTRA NELLO STATO 2");
                                form2.Aggiungi_testo("Ricevente: ENTRA NELLO STATO 2, mentre il mittente è allo stato " + this.state_mitt + "\n", 2);
                                this.state2_ric();
                                break;
                        }
                    }
                }
            }
        }



        //funzioni del mittente

        public void state1_mitt()
        {
            System.Console.WriteLine("THREAD 1 LO STATO 1 INIZIA");
            this.form2.set_flag_opzione(1); //prima di questa istruzione dovrebbe valere 0 visto che prima si istanzia la form e poi la macchina a stati
            this.form2.Invalidate();
            System.Console.WriteLine("THREAD 1 LO STATO 1 HA AGGIORNATO L'INTERFACCIA GRAFICA");

            this.tempo_di_attesa_effettivo_mitt = this.tempo_di_attesa_medio + (new Random().Next(-1, 1));
            System.Threading.Thread.Sleep((int)(this.tempo_di_attesa_effettivo_mitt)); //attende i dati dal livello superiore
            System.Console.WriteLine("THREAD 1 LO STATO 1 HA ASPETTATO");

            this.finestra_di_ricezione = this.buffer_di_ricezione; //perché "all'inizio", in quanto il buffer è vuoto
            //qui sto supponendo che non ci sarà mai un buffer overflow (finestra_di_ricezione=0)

            this.ack_dup_flag = 0; //all' "inizio" bisogna settare a 0 il numero di ACK duplicati
            
            if (this.finestra_di_ricezione > this.dim_rimanenti)
            {
                System.Console.WriteLine("THREAD 1 LO STATO 1 ENTRA NEL IF THIS.FINESTRA_DI_RICEZIONE > THIS.DIM_RIMANENTI");
                this.finestra_di_ricezione = this.dim_rimanenti; //se la finestra di ricezione (numero di segmenti che al massimo vengono mandati tutti in una volta) è più grande di quello che mi rimane da mandare allora diminuisco la finestra di ricezione portandolo alla quantità pari ai dati che mi rimangono da trasmettere

                this.dim_rimanenti = 0; //e così alla fine avrei finito ed è l'ultima volta che fa quel ciclo while
            }
            else this.dim_rimanenti -= this.finestra_di_ricezione;


            //if ( (this.num_seq+1) < (this.num_seq_oldest + this.finestra_di_ricezione)) //num_seq+1 è il prossimo numero di sequenza
            //{
               //System.Console.WriteLine("THREAD 1 LO STATO 1 ENTRA NEL IF THIS.NUM_SEQ_NEXT < (THIS.NUM_SEQ_OLDEST + THIS.FINESTRA_DI_RICEZIONE)");

                //while (this.list_ack.Count <= Math.Min(this.finestra_di_ricezione, this.finestra_di_congestione))
                //{       

                    for (int i = 0; i < this.finestra_di_ricezione; i++)
                    {
                        System.Console.WriteLine("THREAD 1 LO STATO 1 ENTRA NEL FOR I < THIS.FINESTRA_DI_RICEZIONE");

                        this.error_flag = new Random().Next(1, 100);
                        if (this.error_flag <= this.error_rate)
                        {
                            this.list_nak.Add(i); //gli indico quali pacchetti non stati inviati correttamente, e saranno da reinviare
                            this.list_ack.Add(false); //lo aggiungo "negativamente" alla lista degli ack
                            //il numero dei pacchetti da ritrasmettere sarà dato dalla dimensione di questa lista

                          //  if (this.list_ack.Count > Math.Min(this.finestra_di_ricezione, this.finestra_di_congestione))
                            //    this.state3_mitt(); //cioè ci sono altri pacchetti da gestire e quindi ricorsivamente richiamiamo questa funzione

                        }
                        else
                        {
                            this.list_ack.Add(true); //lo aggiungo "positivamente" alla lista degli ack
                            form2.Aggiungi_testo("Mittente: ha inviato il pacchetto n° " + (this.num_seq) + "\n", 1); //questa trasmissione è andata bene
                        }

                        if (i == 0)
                        {
                            this.set_timeout();

                            this.timer = new Thread(this.start_timer);
                            this.timer.Start(); //con if i=0 è come se scattasse solo dopo aver inviato il primo pacchetto dato che è difficile gestire tanti timer quanto sono i pacchetti inviati, facciamo partire solo il timer del primo pacchetto (i=1)
                        }

                        this.num_seq += 1; //aggiorniamo il numero di sequenza; questa istruzione deve essere fatta a prescindere dal fatto che l'invio abbia avuto successo o meno
                    }
                //}
            System.Console.WriteLine("THREAD 1 LO STATO 1 ESCE DAL FOR I < THIS.FINESTRA_DI_RICEZIONE");

            for (int i = 0; i < this.list_ack.Count; i++) //oppure allo stesso modo i < this.list_ack.Count
                if (this.list_ack[i] == true)
                    this.num_seq_oldest += 1;
                else break;
      
            //}
            //System.Console.WriteLine("THREAD 1 LO STATO 1 ESCE DAL IF THIS.NUM_SEQ_NEXT < (THIS.NUM_SEQ_OLDEST + THIS.FINESTRA_DI_RICEZIONE)");


            if (this.list_nak.Count==0) //se la lista dei nak (ossia dei segmenti da rimandare) è vuota
                this.finestra_di_congestione += this.finestra_di_congestione; //la finestra di congestione raddoppia perché è andato bene e raddoppia l'MSS (slow start)
            //else ci penserà poi lo stato 3 ad avviare il meccanismo di congestione della congestione

            this.lock_mitt = true; //il mittente ha finito per il momento
            this.lock_ric = false; //e contemporaneamente si deve attivare il ricevente
            System.Console.WriteLine("THREAD 1 LO STATO 1 HA SETTATO IL LOCK");

            this.set_state_mitt(2); //cambia lo stato
            System.Console.WriteLine("THREAD 1 LO STATO 1 VUOLE PASSARE ALLO STATO 2");
        }

        public void state2_mitt()
        {
            System.Console.WriteLine("THREAD 1 LO STATO 2 INIZIA");
            this.form2.set_flag_opzione(2);
            this.form2.Invalidate();
            System.Console.WriteLine("THREAD 1 LO STATO 2 HA CAMBIATO L'INTERFACCIA GRAFICA");

            form2.Aggiungi_testo("Mittente: sto aspettando e verificando la risposta del ricevente...\n", 1);

            this.tempo_di_attesa_effettivo_mitt = this.tempo_di_attesa_medio + (new Random().Next(-1, 1));
            System.Threading.Thread.Sleep((int)(this.tempo_di_attesa_effettivo_mitt)); //tempo di attesa dell' RTT che va dal ricevente (che aveva già aspettato) al mittente
            System.Console.WriteLine("THREAD 1 LO STATO 2 HA ASPETTATO");

            if (this.timer.IsAlive)
                this.timer.Abort(); //stoppiamo il timeout per fare la verifica
            else System.Console.WriteLine("Mittente: il timer non può essere stoppato perché non è stato avviato");

            if (this.timeout!=0) //se il timeout non è scaduto allora posso andare nello stato della verifica
            {
                System.Console.WriteLine("THREAD 1 LO STATO 2 ENTRA NEL IF THIS.TEMPO_DI_ATTESA_EFFETTIVO_MITT < THIS.TIMEOUT");

                if (this.list_nak.Count == 0) //tutti i pacchetti sono stati inviati
                {
                    System.Console.WriteLine("THREAD 1 LO STATO 2 ENTRA NEL IF THIS.LIST_NAK.COUNT == 0");
                    this.set_state_mitt(4);
                    System.Console.WriteLine("THREAD 1 LO STATO 2 VUOLE PASSARE ALLO STATO 4");
                    //non locka
                }
                else
                {
                    System.Console.WriteLine("THREAD 1 LO STATO 2 ENTRA NEL ELSE THIS.LIST_NAK.COUNT == 0");

                    this.set_state_mitt(3);
                    System.Console.WriteLine("THREAD 1 LO STATO 2 VUOLE PASSARE ALLO STATO 3");
                }
            }

            else
            { //ossia se il timeout era scaduto devo ritrasmettere tutto
                System.Console.WriteLine("THREAD 1 LO STATO 2 ENTRA NEL ELSE THIS.TEMPO_DI_ATTESA_EFFETTIVO_MITT < THIS.TIMEOUT");
                //this.flag_ritr = 0;
                this.num_seq -= this.finestra_di_ricezione; //ritrasmissione totale vuol dire "tornare" allo stato precedente quindi devo sistemare i valori coerentemente
                this.dim_rimanenti += this.finestra_di_ricezione; //+= perché in realtà non sono stati inviati, quindi i dim_rimanenti devono aumentare
                form2.Aggiungi_testo("Mittente: timeout scaduto, ritrasmissione di tutti i segmenti della finestra in corso...\n", 1);
                this.set_state_mitt(1);
                System.Console.WriteLine("THREAD 1 LO STATO 2 VUOLE PASSARE ALLO STATO 1");
                //non locka
            }

            //non devo lockare nulla, cioè il mittente deve eseguire subito il prossimo stato
        }

        public void state3_mitt()
        {
            System.Console.WriteLine("THREAD 1 LO STATO 3 INIZIA");
            this.form2.set_flag_opzione(3);
            this.form2.Invalidate();
            System.Console.WriteLine("THREAD 1 LO STATO 3 HA AGGIORNATO L'INTERFACCIA GRAFICA");

            //non deve aspettare nulla perché si trova in questo stato per ritrasmettere

            this.ack_dup_flag += 1; //trovarsi in questo stato vuol dire che è già fallito (almeno) una volta l'ultimo pacchetto (seq_num_oldest) quindi il conteggio degli ACK duplicati deve aumentare

            if (this.ack_dup_flag == 3) //se vengono inviati 3 ack duplicati si effettua una ritrasmissione rapida
            {
                System.Console.WriteLine("THREAD 1 LO STATO 3 ENTRA NELLA RITRASMISSIONE RAPIDA");
                this.error_flag = new Random().Next(1, 100); 
                if (this.error_flag <= this.error_rate)
                {
                    this.ack_dup_flag = 2; //così, essendo fallita questa trasmissione, quando rientra la prossima volta verrà aumentato di 1 e rivarrà 3 (di nuovo ritrasmissione rapida)
                }
                else
                {

                    form2.Aggiungi_testo("Mittente: ha effettuato una ritrasmissiome rapida e ha inviato il pacchetto n° " + (this.num_seq_oldest) + "\n", 1);
                    this.ack_dup_flag = 0;
                    
                    for(int i=1; i<this.list_ack.Count; i++)
                        if (this.list_ack[i] == false)
                        {
                            this.list_ack[i] = true;
                            break; //deve cambiare solo il primo false in true e poi esce
                        }
                    this.list_nak.RemoveAt(0); //rimuove il primo elemento, ossia il più vecchio che non era stato mandato


                    for (int i = 0; i < this.list_ack.Count; i++) //ricontiamo il giusto num_seq_oldest del ricevente come abbiamo fatto nel primo stato del mittente
                        if (this.list_ack[i] == true)
                            this.num_seq_oldest += 1;
                        else break;
                }

                this.lock_mitt = true;
                this.lock_ric = false;
                System.Console.WriteLine("THREAD 1 LO STATO 3 HA SETTATO I LOCK");

                this.set_state_mitt(2);
                System.Console.WriteLine("THREAD 1 LO STATO 3 VUOLE PASSARE ALLO STATO 2");
            }

            else //se è ritrasmissione parziale
            {
                System.Console.WriteLine("THREAD 1 LO STATO 3 ENTRA NELLA RITRASMISSIONE PARZIALE");

                this.R = this.tempo_di_attesa_effettivo_mitt;
                this.W = this.finestra_di_congestione;
                form3.Aggiungi_testo("RTT = " + this.R + "\nW = " + this.W + "\n");

                if (this.modalità_congestione == 0) 
                    this.Reno();
                else this.Tahoe(); //se si verifica un errore nell'invio del pacchetto c'è stato un errore per l'eccessivo traffico (si suppone) e si richiama il meccanismo di gestione della congestione scelto all'inizio

                form2.Aggiungi_testo("Mittente: sto ritrasmettendo i segmenti non arrivati a destinazione, ossia: \n", 1);

                for (int i = 0; i < this.list_nak.Count; i++) //per tutti i NAK
                {
                    form2.Aggiungi_testo(this.list_nak[i] + ", ", 1);
                    System.Console.WriteLine("THREAD 1 LO STATO 3 ENTRA NEL FOR I < THIS.LIST_NAK.COUNT");

                    if (i == 0) //solo se siamo al primo ciclo
                    {
                        this.set_timeout();

                        this.timer = new Thread(this.start_timer);
                        this.timer.Start();
                        //dato che è difficile gestire tanti timer quanto sono i pacchetti inviati, facciamo partire solo il timer del primo pacchetto (i=1)
                    }

                    this.error_flag = new Random().Next(1, 100);
                    if (this.error_flag <= this.error_rate)
                    {
                        //non succede niente, non gli indico quali pacchetti non stati inviati correttamente, e saranno da reinviare la prossima volta che il mittente entra nello stato di ritrasmissione

                        /*if (i == 1) 
                            this.ack_dup_flag += 1;*/
                    }

                    else
                    {
                        //if (i == 1) this.ack_dup_flag = 0; //riazzeriamo il numero di ack duplicati perché è stato inviato

                        for (int j = 0; j < this.list_ack.Count; j++)
                            if (this.list_ack[j] == false)
                            {
                                this.list_ack[j] = true;
                                break; //deve cambiare solo il primo false in true e poi esce
                            }
                
                        form2.Aggiungi_testo("Mittente: ha ritrasmesso il pacchetto n° " + (this.list_nak[i]) + "\n", 1);
                        this.list_nak.RemoveAt(i);
                    }
                    System.Console.WriteLine("THREAD 1 LO STATO 3 ESCE DAL FOR I < THIS.LIST_NAK.COUNT");
                }
                
                //this.nak_flag = 0; //così se ci sono perdite nelle ritrasmissioni riapplico iterativamente la stessa procedura

                this.lock_mitt = true;
                this.lock_ric = false;
                System.Console.WriteLine("THREAD 1 LO STATO 3 HA SETTATO I LOCK");

                this.set_state_mitt(2); //devo tornare allo stato 2 per l'attesa
                System.Console.WriteLine("THREAD 1 LO STATO 3 VUOLE PASSARE ALLO STATO 2");
            }
        }

        public void state4_mitt()
        {
            System.Console.WriteLine("THREAD 1 LO STATO 4 HA INIZIATO");
            this.form2.set_flag_opzione(4);
            this.form2.Invalidate();
            System.Console.WriteLine("THREAD 1 LO STATO 4 HA AGGIORNATO L'INTERFACCIA GRAFICA");

            //lo stato 4 non ha bisogno di aspettare, poi aspetterà lo stato 1
        
            this.list_ack= new List<Boolean>(); //rimuovo tutti e reinizializzo la lista
            this.list_nak= new List<int>();
    
            if (this.num_seq >= 2 * this.finestra_di_ricezione)
              {
                  this.num_seq = 1; //riutilizziamo i numeri di sequenza assumendo che i segmenti abbiamo un fissato TTL
                  this.num_seq_oldest = 0;
              }

                this.set_state_mitt(1); //essendo gli ACK cumulativi vorrebbe dire che il ricevente ha ricevuto tutto correttamente
                System.Console.WriteLine("THREAD 1 LO STATO 4 VUOLE PASSARE ALLO STATO 1");

              //non devo lockare nulla
        }

        public void set_state_mitt(int flag)
        { //qui gestisco i passaggi di stato

            switch (flag)
            {
                case 1: this.state_mitt = "state1"; System.Console.WriteLine("THREAD 1 LO STATO E' STATO CAMBIATO"); break;
                case 2: this.state_mitt = "state2"; System.Console.WriteLine("THREAD 1 LO STATO E' STATO CAMBIATO"); break;
                case 3: this.state_mitt = "state3"; System.Console.WriteLine("THREAD 1 LO STATO E' STATO CAMBIATO"); break;
                default: this.state_mitt = "state4"; System.Console.WriteLine("THREAD 1 LO STATO E' STATO CAMBIATO"); break;
            }
        }



        public void Reno()
        {
            this.finestra_di_congestione = (this.finestra_di_congestione / 2);
            System.Console.WriteLine("THREAD 1 LO STATO 3 HA EFFETTUATO RENO");
            form2.Aggiungi_testo("Mittente: ha usato il metodo di controllo della congestione Reno\n", 1);
        }

        public void Tahoe() //con questi due metodi implemento i due meccanismi di controllo della congestione
        {
            this.finestra_di_congestione = 1;
            System.Console.WriteLine("THREAD 1 LO STATO 3 HA EFFETTUATO TAHOE");
            form2.Aggiungi_testo("Mittente: ha usato il metodo di controllo della congestione Tahoe\n", 1);
        }




        public void set_timeout() //una funziona che in base ai valori che passati, setta il prossimo/nuovo valore di timeout
        {
            System.Console.WriteLine("THREAD 1 STA PER SETTARE IL TIMEOUT");
            this.somma_parziale = 0;
            this.sample_rtt = (this.tempo_di_attesa_effettivo_ric/1000); //divido per mille perché in input è messo in millisecondi quindi metto 1000 quando in realtà è un secondo; inoltre in teoria dovrei però fare in modo che il sample_rtt non venga calcolato per i segmenti ritrasmessi (come in teoria avviene nel TCP)
            this.list_sample_rtt.Add(this.sample_rtt); //salvo il campione nell'array dinamico
            
            this.rtt_flag = this.list_sample_rtt.Count; //ricavo la dimensione della lista
            IEnumerator<float> i = this.list_sample_rtt.GetEnumerator();
            for (int j = 0; j < this.rtt_flag; j++) //scorro tutti gli elementi della lista
            {
                this.somma_parziale += i.Current;
                i.MoveNext(); //sposta l'enumeratore in avanti
            }

            this.estimated_rtt_old = this.somma_parziale / this.rtt_flag;
            this.estimated_rtt_new = (float)((0.875 * this.estimated_rtt_old) + (0.125 * this.sample_rtt)); //ponendo alfa=0.125; (float) è necessario per la compilazione
            this.dev_rtt_new = (float)((0.75 * this.dev_rtt_old) + 0.75 * (Math.Abs((this.sample_rtt - this.estimated_rtt_new)))); //ponendo beta=0.25; Math.Abs esegue il valore assoluto
            this.timeout = this.estimated_rtt_new + 4 * (this.dev_rtt_new);

            //this.estimated_rtt_old = this.estimated_rtt_new; //la prossima volta che questa funzione verrà richiamata avrà questi new che saranno old
            //this.dev_rtt_old = this.dev_rtt_new;

            this.timeout *= 2; //per debug e per farlo funzionare
            System.Console.WriteLine("THREAD 1 HA SETTATO IL TIMEOUT A " + this.timeout);
        }

        public void start_timer() //questa funzione dovrebbe essere un run perché essa dovrebbe essere eseguita mentre il resto continua ad essere eseguito, quindi ci vuole un thread
        {
            System.Console.WriteLine("THREAD 3 IL TIMEOUT E' PARTITO");
            while (this.timeout >= 1) //ossia finché non si annulla il timeout
            {
                this.timer.Join(1000); //dovrebbe aspettare
                this.timeout -= 1;
                System.Console.WriteLine("THREAD 3 IL TIMEOUT E' DIMINUITO A " + this.timeout);
            }

            this.timer.Join(999); //approssimativamente, arrotondiamo per eccesso
            this.timeout = 0;
            System.Console.WriteLine("THREAD 3 IL TIMEOUT E' SCADUTO");
        }



        //funzioni del ricevente

        public void state1_ric()
        {
            System.Console.WriteLine("THREAD 2 LO STATO 1 INIZIA");
            this.form2.set_flag_opzione(5);
            this.form2.Invalidate();
            System.Console.WriteLine("THREAD 2 LO STATO 1 AGGIORNA L'INTERFACCIA GRAFICA");

            this.form2.Aggiungi_testo("Ricevente: sta aspettando l'arrivo dei pacchetti...\n", 2);
            this.tempo_di_attesa_effettivo_ric = this.tempo_di_attesa_medio + (new Random().Next(-1, 1));
            System.Threading.Thread.Sleep((int)(this.tempo_di_attesa_effettivo_ric)); //attesa di 1 RTT dal mittente al ricevente 
            System.Console.WriteLine("THREAD 2 LO STATO 1 HA ASPETTATO");

            //this.finestra_di_ricezione = this.buffer_di_ricezione - this.nak_flag; //controllo del flusso, dove nak_flag avrà un valore diverso da 0 solo se si tratta di una ritrasmissione, e quindi va limitata la finestra di ricezione(il valore massimo della finestra di ricezione è settato a buffer di ricezione) 

            if(this.list_nak.Count==0)  //se tutti i segmenti erano stati inviati correttamente
                this.form2.Aggiungi_testo("Ricevente: ha inviato l'ACK " + (this.num_seq-1) + "\n", 2);
            else 
                this.form2.Aggiungi_testo("Ricevente: ha inviato l'ACK " + this.num_seq_oldest + "\n", 2);

            this.set_state_ric(2);
            System.Console.WriteLine("THREAD 2 LO STATO 1 VUOLE PASSARE ALLO STATO 2");
        }

        public void state2_ric()
        {
            System.Console.WriteLine("THREAD 2 LO STATO 2 INIZIA");
            this.form2.set_flag_opzione(6);
            this.form2.Invalidate();
            //form2.Simulazione_Paint(this, this.form2.e);
            System.Console.WriteLine("THREAD 2 LO STATO 2 HA AGGIORNATO L'INTERFACCIA GRAFICA");

            this.lock_ric = true; //il ricevente ha finito per il momento quindi si deve stoppare
            this.lock_mitt = false; //e contemporaneamente deve far ripartire il mittente
            System.Console.WriteLine("THREAD 2 LO STATO 2 HA SETTATO I LOCK");

            this.set_state_ric(1);
            System.Console.WriteLine("THREAD 2 LO STATO 2 VUOLE PASSARE ALLO STATO 2");
        }

        public void set_state_ric(int flag)
        {
            switch (flag)
            {
                case 1: this.state_ric = "state1"; System.Console.WriteLine("THREAD 2 LO STATO E' STATO CAMBIATO"); break;
                default: this.state_ric = "state2"; System.Console.WriteLine("THREAD 2 LO STATO E' STATO CAMBIATO"); break;
            }
        }



    }
    }

