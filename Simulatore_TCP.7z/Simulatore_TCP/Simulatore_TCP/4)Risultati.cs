﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Simulatore_TCP
{
    public partial class Risultati : Form
    {

        delegate void SetTRichTextCallback(string s); //s è il testo

        public Risultati()
        {
            InitializeComponent();
        }

        public void Aggiungi_testo(string s)
        {
            if (this.richTextBox1.InvokeRequired)
            {
                SetTRichTextCallback d = new SetTRichTextCallback(Aggiungi_testo);
                this.Invoke(d, new object[] { s });
            }
            else
            {
                //this.richTextBox1.AppendText(s);
                this.richTextBox1.Text = s;
            }
        }

        private void label2_Click(object sender, EventArgs e) //metodo necessario anche se vuoto per avere la visualizzazione di questo form
        {

        }
    }
}
