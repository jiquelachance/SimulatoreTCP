﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simulatore_TCP
{
    interface Macchina_a_stati_ricevente_TCP
    {
        void state1_ric();  
        void state2_ric();  



        void set_state_ric(int flag); 

    }
}
