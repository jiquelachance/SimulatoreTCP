﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Simulatore_TCP
{
    public partial class Simulazione : Form
    {
        public Risultati form3;
        public int flag_opzione;


        public event EventHandler aggiornamento_stato;
        public PaintEventArgs e;

        delegate void SetTRichTextCallback(string s, int n); //s è il testo
        delegate void SetTRichTextCallback2();


        public Simulazione()
        {
            this.flag_opzione = 0;
            InitializeComponent();
            System.Console.WriteLine("FORM3 INIZIALIZZATA");
            Risultati form3 = new Risultati();

            this.button1.Hide(); //durante la simulazione il bottone per passare all'ultima finestra deve essere disabilitato

            this.form3 = form3;
        }



        
        public void Final() //da richiamare solo alla fine della simulazione
        {
            if (this.button1.InvokeRequired)
            {
                SetTRichTextCallback2 e = new SetTRichTextCallback2(Final);
                this.Invoke(e, new object[] { });
            }
            else
            {
                this.button1.Show();
            }
          
        }

        public void Aggiungi_testo(string s, int n) //s è la stringa da stampare nelle caselle di testo, n è un flag:se n=1 allora la stringa riguarda il mittente e quindi devi stamparlo nella casella di testo apposita (di sinistra), mentre se è 2 nel destinatario
        {
            System.Console.WriteLine("SI ENTRA NELLA FUNZIONE AGGIUNGI_TESTO");
            if (n == 1)
            {
                if (this.richTextBox1.InvokeRequired)
                {
                    SetTRichTextCallback d = new SetTRichTextCallback(Aggiungi_testo);
                    this.Invoke(d, new object[] { s + "\n", 1 });
                }
                else
                {
                    this.richTextBox1.AppendText(s + "\n");
                }
            }

            if (n == 2)
            {
                if (this.richTextBox2.InvokeRequired)
                {
                    SetTRichTextCallback d = new SetTRichTextCallback(Aggiungi_testo);
                    this.Invoke(d, new object[] { s + "\n", 2 });
                }
                else
                {
                    this.richTextBox2.AppendText(s + "\n");
                }
            }
            System.Console.WriteLine("SI ESCE DALLA FUNZIONE AGGIUNGI_TESTO");
        }

        public void set_flag_opzione(int i)
        {
            System.Console.WriteLine("FLAG_OPZIONE VIENETE SETTATA A " + i);
            this.flag_opzione = i;
        }

        //private void Simulazione_Paint(object sender, PaintEventArgs e) //questo metodo viene chiamato ogni volta che il modulo finestra viene spostato , ridimensionato o ripristinato, e non bsogna richiamarlo dall'esterno
        public void Simulazione_Paint(object sender, PaintEventArgs e)
        {
            this.e = e;

            System.Console.WriteLine("SI ENTRA NELLA FUNZIONE SIMULAZIONE_PAINT");
            //tutte queste misure verranno tutte traslate di una stessa quantità in x e y in base alla dimensioni della finestra
            if (this.flag_opzione == 0)
            {
                //Creazione ellissi mittente
                //Ellisse a sinistra (stato 1)
                e.Graphics.FillEllipse(Brushes.Blue, 15, 415, 180, 80); //riempie di blu l'ellisse, che si trova là, con quelle dimensioni
                e.Graphics.DrawEllipse(Pens.Blue, 15, 415, 180, 80); //disegna un'ellisse lì e con quelle dimensioni
                Point a = new Point(195, 455); //creo due punti attraverso cui devo far passare una linea
                Point b = new Point(215, 355);
                e.Graphics.DrawLine(Pens.Blue, a, b);
                //Ellisse in alto (stato 2)
                e.Graphics.FillEllipse(Brushes.Blue, 215, 315, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 215, 315, 180, 80);
                Point c = new Point(395, 355);
                Point d = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, c, d);
                //Ellisse in basso (stato 4)
                e.Graphics.FillEllipse(Brushes.Blue, 215, 515, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 215, 515, 180, 80);
                Point f = new Point(195, 455);
                Point g = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, f, g);
                //Ellisse a destra (stato 3)
                e.Graphics.FillEllipse(Brushes.Blue, 415, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 415, 415, 180, 80);
                Point h = new Point(310, 355);
                Point i = new Point(310, 545);
                e.Graphics.DrawLine(Pens.Blue, h, i);

                //Creazioni ellissi destinatario
                //Ellisse a sinistra (stato 1)
                e.Graphics.FillEllipse(Brushes.Red, 715, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Red, 715, 415, 180, 80);
                Point j = new Point(895, 445);
                Point k = new Point(915, 445);
                e.Graphics.DrawLine(Pens.Red, j, k);
                //Ellisse a destra (stato 2)
                e.Graphics.FillEllipse(Brushes.Red, 915, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Red, 915, 415, 180, 80);
                Point l = new Point(895, 465);
                Point m = new Point(915, 465);
                e.Graphics.DrawLine(Pens.Red, l, m);
            }

            if (this.flag_opzione == 1) //aggiorno gli stati nella form (le ellissi) facendogli cambiare colore in giallo, e ciò devo farlo ogni volta che la classe Mittente_TCP genera un evento che gestisco qui
            { //stato 1 del mittente
                e.Graphics.FillEllipse(Brushes.Yellow, 15, 415, 180, 80); //il primo a sinistra
                e.Graphics.DrawEllipse(Pens.Yellow, 15, 415, 180, 80);  //con queste due linee ho cambiato i colori di un solo stato, ma nelle successive devo comunque risettare tutti gli altri del colore predefinito (altrimenti alla fine del primo ciclo sarebbero tutti gialli; l'alternativa sarebbe stata generare l'evento della comparsa del paint per averli tutti predefiniti e poi in base al case del flag coloro solo quello giusto, con Simulazione_Paint(sender, e));

                e.Graphics.FillEllipse(Brushes.Blue, 215, 315, 180, 80); //quello in alto
                e.Graphics.DrawEllipse(Pens.Blue, 215, 315, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 215, 515, 180, 80); //quello in basso
                e.Graphics.DrawEllipse(Pens.Blue, 215, 515, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 415, 415, 180, 80); //quello a destra
                e.Graphics.DrawEllipse(Pens.Blue, 415, 415, 180, 80);

                Point a = new Point(195, 455); //lascio le linee
                Point b = new Point(215, 355);
                e.Graphics.DrawLine(Pens.Blue, a, b);
                Point c = new Point(395, 355);
                Point d = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, c, d);
                Point f = new Point(195, 455);
                Point g = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, f, g);
                Point h = new Point(310, 355);
                Point i = new Point(310, 545);
                e.Graphics.DrawLine(Pens.Blue, h, i);
                Point j = new Point(895, 445);
                Point k = new Point(915, 445);
                e.Graphics.DrawLine(Pens.Red, j, k);
                Point l = new Point(895, 465);
                Point m = new Point(915, 465);
                e.Graphics.DrawLine(Pens.Red, l, m);

                e.Graphics.FillEllipse(Brushes.Red, 715, 415, 180, 80); //quelli del destinatario rimangono
                e.Graphics.DrawEllipse(Pens.Red, 715, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Red, 915, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Red, 915, 415, 180, 80);
            }

            if (this.flag_opzione == 2)
            { //stato 2 del mittente
                e.Graphics.FillEllipse(Brushes.Yellow, 215, 315, 180, 80); //quello in alto
                e.Graphics.DrawEllipse(Pens.Yellow, 215, 315, 180, 80);

                e.Graphics.FillEllipse(Brushes.Blue, 15, 415, 180, 80); //il primo a sinistra
                e.Graphics.DrawEllipse(Pens.Blue, 15, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 215, 515, 180, 80); //quello in basso
                e.Graphics.DrawEllipse(Pens.Blue, 215, 515, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 415, 415, 180, 80); //quello a destra
                e.Graphics.DrawEllipse(Pens.Blue, 415, 415, 180, 80);

                Point a = new Point(195, 455); //lascio le linee
                Point b = new Point(215, 355);
                e.Graphics.DrawLine(Pens.Blue, a, b);
                Point c = new Point(395, 355);
                Point d = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, c, d);
                Point f = new Point(195, 455);
                Point g = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, f, g);
                Point h = new Point(310, 355);
                Point i = new Point(310, 545);
                e.Graphics.DrawLine(Pens.Blue, h, i);
                Point j = new Point(895, 445);
                Point k = new Point(915, 445);
                e.Graphics.DrawLine(Pens.Red, j, k);
                Point l = new Point(895, 465);
                Point m = new Point(915, 465);
                e.Graphics.DrawLine(Pens.Red, l, m);

                e.Graphics.FillEllipse(Brushes.Red, 715, 415, 180, 80); //quelli del destinatario rimangono
                e.Graphics.DrawEllipse(Pens.Red, 715, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Red, 915, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Red, 915, 415, 180, 80);
            }

            if (this.flag_opzione == 3)
            { //stato 3 del mittente
                e.Graphics.FillEllipse(Brushes.Yellow, 415, 415, 180, 80); //quello a destra
                e.Graphics.DrawEllipse(Pens.Yellow, 415, 415, 180, 80);

                e.Graphics.FillEllipse(Brushes.Blue, 215, 315, 180, 80); //quello in alto
                e.Graphics.DrawEllipse(Pens.Blue, 215, 315, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 215, 515, 180, 80); //quello in basso
                e.Graphics.DrawEllipse(Pens.Blue, 215, 515, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 15, 415, 180, 80); //il primo a sinistra
                e.Graphics.DrawEllipse(Pens.Blue, 15, 415, 180, 80);

                Point a = new Point(195, 455); //lascio le linee
                Point b = new Point(215, 355);
                e.Graphics.DrawLine(Pens.Blue, a, b);
                Point c = new Point(395, 355);
                Point d = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, c, d);
                Point f = new Point(195, 455);
                Point g = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, f, g);
                Point h = new Point(310, 355);
                Point i = new Point(310, 545);
                e.Graphics.DrawLine(Pens.Blue, h, i);
                Point j = new Point(895, 445);
                Point k = new Point(915, 445);
                e.Graphics.DrawLine(Pens.Red, j, k);
                Point l = new Point(895, 465);
                Point m = new Point(915, 465);
                e.Graphics.DrawLine(Pens.Red, l, m);

                e.Graphics.FillEllipse(Brushes.Red, 715, 415, 180, 80); //quelli del destinatario rimangono
                e.Graphics.DrawEllipse(Pens.Red, 715, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Red, 915, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Red, 915, 415, 180, 80);
            }

            if (this.flag_opzione == 4)
            {//stato 4 del mittente
                e.Graphics.FillEllipse(Brushes.Yellow, 215, 515, 180, 80); //quello in basso
                e.Graphics.DrawEllipse(Pens.Yellow, 215, 515, 180, 80);

                e.Graphics.FillEllipse(Brushes.Blue, 215, 315, 180, 80); //quello in alto
                e.Graphics.DrawEllipse(Pens.Blue, 215, 315, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 15, 415, 180, 80); //il primo a sinistra
                e.Graphics.DrawEllipse(Pens.Blue, 15, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 415, 415, 180, 80); //quello a destra
                e.Graphics.DrawEllipse(Pens.Blue, 415, 415, 180, 80);

                Point a = new Point(195, 455); //lascio le linee
                Point b = new Point(215, 355);
                e.Graphics.DrawLine(Pens.Blue, a, b);
                Point c = new Point(395, 355);
                Point d = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, c, d);
                Point f = new Point(195, 455);
                Point g = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, f, g);
                Point h = new Point(310, 355);
                Point i = new Point(310, 545);
                e.Graphics.DrawLine(Pens.Blue, h, i);
                Point j = new Point(895, 445);
                Point k = new Point(915, 445);
                e.Graphics.DrawLine(Pens.Red, j, k);
                Point l = new Point(895, 465);
                Point m = new Point(915, 465);
                e.Graphics.DrawLine(Pens.Red, l, m);

                e.Graphics.FillEllipse(Brushes.Red, 715, 415, 180, 80); //quelli del destinatario rimangono
                e.Graphics.DrawEllipse(Pens.Red, 715, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Red, 915, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Red, 915, 415, 180, 80);
            }

            if (this.flag_opzione == 5)
            { //stato 1 del destinatario
                e.Graphics.FillEllipse(Brushes.Yellow, 715, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Yellow, 715, 415, 180, 80);

                e.Graphics.FillEllipse(Brushes.Red, 915, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Red, 915, 415, 180, 80);

                Point a = new Point(195, 455); //lascio le linee
                Point b = new Point(215, 355);
                e.Graphics.DrawLine(Pens.Blue, a, b);
                Point c = new Point(395, 355);
                Point d = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, c, d);
                Point f = new Point(195, 455);
                Point g = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, f, g);
                Point h = new Point(310, 355);
                Point i = new Point(310, 545);
                e.Graphics.DrawLine(Pens.Blue, h, i);
                Point j = new Point(895, 445);
                Point k = new Point(915, 445);
                e.Graphics.DrawLine(Pens.Red, j, k);
                Point l = new Point(895, 465);
                Point m = new Point(915, 465);
                e.Graphics.DrawLine(Pens.Red, l, m);

                e.Graphics.FillEllipse(Brushes.Blue, 15, 415, 180, 80); //quelli del mittente rimangono
                e.Graphics.DrawEllipse(Pens.Blue, 15, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 415, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 415, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 215, 515, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 215, 515, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 215, 315, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 215, 315, 180, 80);
            }

            if (this.flag_opzione == 6)
            { //stato 2 del destinatario
                e.Graphics.FillEllipse(Brushes.Yellow, 915, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Yellow, 915, 415, 180, 80);

                e.Graphics.FillEllipse(Brushes.Red, 715, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Red, 715, 415, 180, 80);

                Point a = new Point(195, 455); //lascio le linee
                Point b = new Point(215, 355);
                e.Graphics.DrawLine(Pens.Blue, a, b);
                Point c = new Point(395, 355);
                Point d = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, c, d);
                Point f = new Point(195, 455);
                Point g = new Point(415, 455);
                e.Graphics.DrawLine(Pens.Blue, f, g);
                Point h = new Point(310, 355);
                Point i = new Point(310, 545);
                e.Graphics.DrawLine(Pens.Blue, h, i);
                Point j = new Point(895, 445);
                Point k = new Point(915, 445);
                e.Graphics.DrawLine(Pens.Red, j, k);
                Point l = new Point(895, 465);
                Point m = new Point(915, 465);
                e.Graphics.DrawLine(Pens.Red, l, m);

                e.Graphics.FillEllipse(Brushes.Blue, 15, 415, 180, 80); //quelli del mittente rimangono
                e.Graphics.DrawEllipse(Pens.Blue, 15, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 415, 415, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 415, 415, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 215, 515, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 215, 515, 180, 80);
                e.Graphics.FillEllipse(Brushes.Blue, 215, 315, 180, 80);
                e.Graphics.DrawEllipse(Pens.Blue, 215, 315, 180, 80);
            }

            //this.Invalidate();
            //this.Refresh();
            //this.Update();

            System.Console.WriteLine("SI ESCE DALLA FUNZIONE ON_AGGIORNAMENTO_STATO");
        }


        private void button1_Click_1(object sender, EventArgs e) //se si preme il tasto mostra risultati, che già c'era ma solo ora viene visualizzata effettivamente, e questa form si chiude
        {
            this.Hide();
            form3.Show();
            //Application.Run(form3);
            //this.Close();
        }
    }
}