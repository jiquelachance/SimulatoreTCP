﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simulatore_TCP
{
    interface Macchina_a_stati_mittente_TCP
    {
        void state1_mitt();  
        void state2_mitt();   
        void state3_mitt();   
        void state4_mitt();  




        void set_state_mitt(int flag); //cambia gli stati


    }
}
