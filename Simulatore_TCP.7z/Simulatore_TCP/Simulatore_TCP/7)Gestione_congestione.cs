﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simulatore_TCP
{
    interface Gestione_congestione //è necessario, per ogni classe macchina a stati TCP definire metodi che implementano i meccanismi di gestione della congestione
    {
        void Reno();

        void Tahoe();
    }
}
